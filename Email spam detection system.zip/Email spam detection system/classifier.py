from flask import Flask, render_template, request, jsonify
import joblib

app = Flask(__name__)

# Load the saved model and vectorizer
model = joblib.load("spam_classifier_model.pkl")
vectorizer = joblib.load("tfidf_vectorizer.pkl")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    message = data.get("message", "")
    vec = vectorizer.transform([message])
    pred = model.predict(vec)[0]
    prob = model.predict_proba(vec)[0][1]
    label = "Spam" if pred == 1 else "Not Spam"
    return jsonify({"label": label, "probability": round(prob * 100, 2)})

if __name__ == "__main__":
    app.run(debug=True)