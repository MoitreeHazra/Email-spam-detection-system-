const form = document.getElementById("spamForm");
const resetBtn = document.getElementById("resetBtn");
const resultDiv = document.getElementById("result");
const messageField = document.getElementById("message");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = messageField.value;

  const response = await fetch("/predict", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ message })
  });

  const data = await response.json();
  resultDiv.innerHTML = `<span style="color:${data.label === 'Spam' ? 'red' : 'green'}">${data.label}</span><br>Spam Probability: ${data.probability}%`;
});

resetBtn.addEventListener("click", () => {
  messageField.value = "";
  resultDiv.innerHTML = "";
});